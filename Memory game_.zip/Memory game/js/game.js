// Load an audio file
var audioWin = new Audio('sound/win.mp3');
var right = new Audio('sound/right.mp3');
var wrong = new Audio('sound/wrong.mp3');
// Those are global variables, they stay alive and reflect the state of the game
var elPreviousCard = null;
var flippedCouplesCount = 0;
var total_clicks = 0;
var wrong_clicks = 0;
var IncorrectClicks;

// This is a constant that dont change during the game
var TOTAL_COUPLES_COUNT = 6;

// This function is called whenever the user click a card
function cardClicked(elCard) {

    // If the user clicked an already flipped card - do nothing and return from the function
    if (elCard.classList.contains('flipped')) {
        return;
    }

    // Flip it
    else {
        total_clicks++;
        elCard.classList.add('flipped');
    }
    //Clicks_Status = "Total clicks: " + total_clicks;
    //document.getElementById("clickCount").innerHTML = Clicks_Status;

    // This is a first card, only keep it in the global variable
    if (elPreviousCard === null) {
        elPreviousCard = elCard;
    } else {
        // get the data-card attribute's value from both cards
        var card1 = elPreviousCard.getAttribute('data-card');
        var card2 = elCard.getAttribute('data-card');

        // No match, schedule to flip them back in x second
        if (card1 !== card2) {
            setTimeout(function () {
                elCard.classList.remove('flipped');
                elPreviousCard.classList.remove('flipped');
                elPreviousCard = null;
                wrong.play();
                wrong_clicks ++;
                IncorrectClicks = "Wrong guesses: " + wrong_clicks;
                document.getElementById("clickCount").innerHTML = IncorrectClicks;
            }, 200)
         
        } 
        
        else {
            // Yes! a match!
            flippedCouplesCount++;
            elPreviousCard = null;
            right.play();

            // All cards flipped!
            if (TOTAL_COUPLES_COUNT === flippedCouplesCount) {
                audioWin.play();
                document.getElementById("modal-wrapper").style.display = "block";
            }

        }
     
       

    }


}

function NewGame() {
    document.getElementById("clickCount").innerHTML = "";
    flippedCouplesCount = 0;
    total_clicks = 0;
    wrong_clicks = 0;
    document.getElementById("modal-wrapper").style.display = "none";
    var removelist = document.getElementsByClassName("card flipped");
    console.log(removelist);
    var l = removelist.length;

    for (i = 0; i < l; i++) {

        removelist[0].classList.remove("flipped");

    }


}

function closeWindow() {
    document.getElementById("modal-wrapper").style.display = "none";
}

